#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Mar 13 17:11:33 2022

@author: vinaynandigam
"""
import numpy as np
import matplotlib.pyplot as plt

def dataPrepare(inputFile):
    lineFeatures=inputFile.readline()
    lineFeatures=lineFeatures.strip()
    lf=lineFeatures.split("\t")
    rows=int(lf[0])
    columns=int(lf[1])
    data=[]
    for i in range(0,rows):
        lineFeatures=inputFile.readline()
        lineFeatures=lineFeatures.strip()
        lineFeatures=lineFeatures.replace(',','')
        data.append(lineFeatures)
    return data,columns

def logisticRegression(train,columns):
    tp=0
    tn=0
    fp=0
    fn=0
    alpha=0.1
    rows_train=len(train)
    
    w=np.zeros((columns+1,1))
    X = np.ones((rows_train,columns+1))
    y = np.zeros((rows_train,1))   
    for i in range(0,rows_train):
        lineFeatures=train[i]
        lf=lineFeatures.split("\t")
        y[i,0] = lf[-1]
        lf=lf[:-1]
        for j in range(1,columns+1):
            X[i,j]=lf[j-1]
    
    x_coordinates=[]
    y_coordinates=[]
    numberOfiterations=100000
    for i in range(0,numberOfiterations):
        h=np.dot(X,w)
        h = 1/(1 + np.exp(-h))
        w=w-((alpha*(1/rows_train))*np.matmul(X.T,(h-y)))
        cost=(y*np.log(h))+((1-y)*(np.log(1-h)))
        cost=np.sum(cost)
        cost=-((1/rows_train)*cost)
        if(i==0):
            initialJ=cost
        x_coordinates.append(i)
        y_coordinates.append(cost)
    print("Weights:",w)
        
    plt.scatter(x_coordinates, y_coordinates,color = "green")
    plt.plot(x_coordinates,y_coordinates,color = "green")
    plt.xlabel("Number of Iterations.")
    plt.ylabel("J values")
    plt.title("Plot")
    plt.show()
    
    fileName1 = input("Enter the name of your test data file:")
    inputFile1 = open(fileName1,"r")
    returnValue=dataPrepare(inputFile1)
    test=returnValue[0]
    columns=returnValue[1]
    rows_test=len(test)
    inputFile1.close()
    
    X1 = np.ones((rows_test,columns+1))
    y1 = np.zeros((rows_test,1))
    y_pred=np.empty((rows_test,1))
    for i in range(0,rows_test):
        lineFeatures1=test[i]
        lf1=lineFeatures1.split("\t")
        y1[i,0] = lf1[-1]
        lf1=lf1[:-1]
        for j in range(1,columns+1):
            X1[i,j]=lf1[j-1]
    
    h1=np.dot(X1, w)
    h1 = 1/(1 + np.exp(-h1))
    test_j=(y1*np.log(h1))+((1-y1)*(np.log(1-h1)))
    test_j=np.sum(test_j)
    test_j=-((1/rows_test)*test_j)
    for i in range(0,rows_test):
        if(h1[i,0]>=0.5):
            y_pred[i,0]=1.0
        else:
            y_pred[i,0]=0.0
            
        if(y_pred[i,0]==y1[i,0]):
            if(y_pred[i,0]==1.0):
                tp+=1
            else:
                tn+=1
        else:
            if(y_pred[i,0]==1.0):
                fp+=1
            else:
                fn+=1  
    
    accuracy = (tp+tn)/(tp+tn+fp+fn)
    precision = (tp)/(tp+fp)
    recall = (tp)/(tp+fn)
    f1=2*(1/((1/precision)+(1/recall)))
    print("\n")
    print("Initial J value in the first iteration: ",initialJ)
    print("Final J Value on training set: ",cost)
    print("J value on test set: ",test_j)
    print("number of iterations ran: ",numberOfiterations)
    print("True Positive count: ", tp)
    print("False Positive count: ", fp)
    print("True Negative count: ", tn)
    print("False Negative count: ", fn)
    print("Accuracy Score: ", accuracy)
    print("Precision Score: ", precision)
    print("Recall Score: ", recall)
    print("F1 Score: ", f1)
    print("\n")

fileName = input("Enter the name of your training data file:")
inputFile = open(fileName,"r")
train=dataPrepare(inputFile)
logisticRegression(train[0],train[1])
inputFile.close()
