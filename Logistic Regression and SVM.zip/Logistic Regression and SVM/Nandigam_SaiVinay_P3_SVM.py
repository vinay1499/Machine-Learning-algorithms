import numpy as np;
import pandas as pd;
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn import svm
from sklearn.svm import SVC
from sklearn import metrics
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score

def load_data(lineFeatures, rows, columns):
    print(lineFeatures)
    X=np.zeros((rows, columns))
    y=np.zeros((rows, 1))
    for i in range(len(lineFeatures)):
        feat_ures=lineFeatures[i].split("\t")
        for j in range(len(feat_ures)-1):
            X[i,j]=float(feat_ures[j])
        y[i]=float(feat_ures[len(feat_ures)-1].replace("\n", ""))

    return X, y



def hyper_plane(svmModel, xTrain, yTrain):



    xlin = np.linspace(-1, 1, 100)
    ylin = np.linspace(-1, 1, 100)
    X, Y = np.meshgrid(xlin, ylin)
    xy = np.vstack([X.ravel(), Y.ravel()]).T
    plane = svmModel.decision_function(xy).reshape(X.shape)

    plt.scatter(xTrain[:, 0], xTrain[:, 1], c = yTrain, s = 10, label="Train")

    plt.contour(X, Y, plane, levels = [-1, 0, 1])
    plt.scatter(svmModel.support_vectors_[:, 0], svmModel.support_vectors_[:, 1], s = 80, facecolors= "none", edgecolors="k", label="Support Vectors")
    plt.legend()
    plt.title("Hyperplane")
    plt.show()
    fileName1 = input("Enter the name of your test data file:")
    inputFile = open(fileName1,"r")
    lineFeatures1=inputFile.readline()
    lineFeatures1=lineFeatures1.strip()
    lf1=lineFeatures1.split("\t")
    rows=int(lf1[0])
    columns=int(lf1[1])
    X_test, y_test=load_data(inputFile.readlines(), rows, columns)
    svmModel.fit(X_train, y_train.ravel())
    y_predict = svmModel.predict(X_test)
     
    print('Accuracy : ',accuracy_score(y_predict,y_test ))

    print("Confusion matrix:",confusion_matrix(y_test, y_predict))
    tn, fp, fn, tp = confusion_matrix(y_test, y_predict).ravel()
    print("True Positive:",tp)
    print("True Negative:",tn)
    print("False Positive:",fp)
    print("False Negative:",fn)
    print('Precision : ', precision_score(y_test,y_predict))

    print('Recall : ',recall_score(y_test,y_predict))
    
    print('F1: ',f1_score(y_test,y_predict))



fileName = input("Enter the name of your training data file:")
inputFile = open(fileName,"r")
lineFeatures=inputFile.readline()
lineFeatures=lineFeatures.strip()
lf=lineFeatures.split("\t")
rows=int(lf[0])
columns=int(lf[1])
X_train, y_train=load_data(inputFile.readlines(), rows, columns)
svmModel = SVC(kernel='rbf')
svmModel.fit(X_train, y_train.ravel())

hyper_plane(svmModel, X_train, y_train)
inputFile.close()