#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 11 15:50:17 2022

@author: vinaynandigam
"""

fileName = input("Enter the name of your training data file:")
inputFile = open(fileName,"r")

fileName1 = input("Enter the name of your file to write:")
fout1=open(fileName1,'w')
lineFeatures=inputFile.readline()
lineFeatures=lineFeatures.strip()
lf=lineFeatures.split("\t")
rows=int(lf[0])
columns=int(lf[1])
thePower = 3

for k in range(0,rows):
    lineFeatures=inputFile.readline()
    lineFeatures=lineFeatures.strip()
    lf=lineFeatures.split("\t")
    x1=float(lf[0])
    x2=float(lf[1])
    y=float(lf[-1])
    for j in range(thePower+1):
        for i in range(thePower+1):
            temp = (x1**i)*(x2**j)
            if (temp != 1):
                fout1.write(str(temp)+"\t")
    fout1.write(str(y)+"\n")


inputFile.close()
fout1.close()