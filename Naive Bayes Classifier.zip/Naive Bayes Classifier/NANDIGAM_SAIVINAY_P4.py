#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Apr 10 14:29:00 2022

@author: vinaynandigam
"""

from math import exp
from math import log

def cleantext(text):
    text=text.lower()
    text=text.strip()
    # Removing the punctuations and strips out the white spaces.
    for letters in text:
        if letters in """[]!.,"-!--@;':#%^&*()+/?=$~""":
            text=text.replace(letters," ") 
    return text

def countwords(words,is_spam,counted):
    #removing duplicated words.
    for each_word in words:
        if each_word in counted:
            if is_spam==1:
                counted[each_word][1]=counted[each_word][1]+1
            else:
                counted[each_word][0]=counted[each_word][0]+1
        else:
            if is_spam==1:
                counted[each_word]=[0,1]
            else:
                counted[each_word]=[1,0]
    return counted

def make_percent_list(k,theCount,spams,hams):
# Record each word as appearing in spam or ham
    for each_key in counted:
        theCount[each_key][0]=(k+ theCount[each_key][0])/(2*k+hams)
        theCount[each_key][1]=(k+ theCount[each_key][1])/(2*k+spams)
    return theCount


def predict(vocab,test_words,probability_spam,probability_ham):
        spam_header=0
        ham_header=0
        for word in vocab:
            if word in test_words:
                spam_header=spam_header+log(vocab[word][1])
                ham_header=ham_header+log(vocab[word][0])
            else:
                spam_header=spam_header+log(1-vocab[word][1])
                ham_header=ham_header+log(1-vocab[word][0])
        
        
        total_spam_prob=exp(spam_header)
        total_ham_prob=exp(ham_header)
        
        
        probability_ham=log(total_ham_prob)+log(probability_ham)
        probability_spam =log(total_spam_prob)+log(probability_spam)
        
        bayes_theorem_exp=exp(probability_ham-probability_spam)
        
        final_probability=1/(1+bayes_theorem_exp)
        
        #print(final_probability)
        if final_probability>=0.5:
            return 1
        else:
            return 0
            
        return
    
def printVocab(vocab):
    print("Word\tHamProb\tHamProb")
    for word in vocab:
        print(word+'\t'+str(vocab[word][0])+'\t'+str(vocab[word][1])) 
        
def printScores(y_test,y_predict):
    pred_falsepositive=0
    pred_falsenegative=0
    pred_truenegative=0
    pred_truepositive=0
    for i in range(len(y_test)):
        if y_test[i]==0 and y_predict[i]==0:
            pred_truenegative+=1
        elif y_test[i]==1 and y_predict[i]==1:
            pred_truepositive+=1
        elif y_test[i]==0 and y_predict[i]==1:
            pred_falsepositive+=1
        elif y_test[i]==1 and y_predict[i]==0:
            pred_falsenegative+=1 
    print("False Positves(FP):\t"+str(pred_falsepositive))
    print("False Negatives(FN):\t"+str(pred_falsenegative))
    print("True Positives(TP):\t"+str(pred_truepositive))
    print("True Negatives(TN):\t"+str(pred_truenegative))
       
    accuracy=(pred_truepositive+pred_truenegative)/(pred_truepositive+pred_truenegative+pred_falsenegative+pred_falsepositive)
    precision=(pred_truepositive)/(pred_truepositive+pred_falsepositive)        
    recall=(pred_truepositive)/(pred_truepositive+pred_falsenegative)
    f_1_score=2*(precision*recall)/(precision+recall)
    
    print("Accuracy value for the Spam filter on the Test Set file:\t"+str(accuracy))  
    print("Precision value for the Spam filter on the Test Set file:\t"+str(precision))
    print("Recall value for the Spam filter on the Test Set file:\t"+str(recall))
    print("F1 Score value for the Spam filter on the Test Set file:\t"+str(f_1_score))
  
    return     

if  __name__=="__main__":
    #Loading the Training File.
    train_file_name=input("Please enter the name of the spam-ham trainng file: " )
    train_file=open(train_file_name,'r',encoding='utf8')
    
    
    line=train_file.readline()
    #Parameter Initialization
    counted=dict()
    #spam count
    spam=0
    #ham count
    ham=0
    
    stop_words_file=input("Please enter the name of the stop words file: " )
    stop_words_file_handle=open(stop_words_file,'r')
    stop_words=[]
    
    stop_words_line=stop_words_file_handle.readline()
    while stop_words_line !="":
        stop_words.append(stop_words_line[:1])
        stop_words_line=stop_words_file_handle.readline()
    
    while line !="":
        
        is_spam=int(line[:1])
        if(is_spam == 1):
            spam+=1
        else:
            ham+=1
        line=cleantext(line[1:])
        words=line.split()
        words=set(words)
        words=words.difference(stop_words)
        #counting the words as appeared in Spam and Ham
        counted=countwords(words,is_spam,counted)
        line = train_file.readline()
    print("Count of how many spam and ham emails contained each word: ",counted)
    vocab=(make_percent_list(1,counted,spam,ham))
    print("Vocabulary with percentages: ",vocab)
    train_file.close() #closing the training file.
    stop_words_file_handle.close()
    probability_spam=spam/(spam+ham)
    probability_ham=ham/(spam+ham)
    test_file_name=input("Please enter the name of the spam-ham test file: ")
    test_file_handler=open(test_file_name,'r',encoding='utf8')
    test_line=test_file_handler.readline()
    test_spam_class=[]
    predict_spam_class=[]

    test_spams=0
    test_hams=0
    while test_line!="":
        test_spam_class.append(int(test_line[:1]))
        if (int(test_line[:1]))==0:
            test_hams=test_hams+1
        else:
            test_spams=test_spams+1
        
        test_line=cleantext(test_line[1:])
        test_words=test_line.split()
        test_words=set(test_words)
        predicted_class=predict(vocab,test_words,probability_spam,probability_ham)
        predict_spam_class.append(predicted_class)
        test_line=test_file_handler.readline()


    print("Number of Spams in Test File\t"+str(test_spams))
    print("Number of Hams in Test File\t"+str(test_hams))
    printScores(test_spam_class,predict_spam_class)