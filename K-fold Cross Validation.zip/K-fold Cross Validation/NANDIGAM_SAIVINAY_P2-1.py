#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Feb  8 15:07:09 2022

@author: vinaynandigam
"""

import numpy as np
w = np.array([[ 1.31307195e+01],
 [-4.32482706e-02],
 [ 2.06369039e-04]])

print("Computed Weights using Quadratic Model : ")
print(w)

year = int(input("Enter the future year to predict the time to complete the run in the format (2008 -> 108): "))
x=np.array(([[1,year,year**2]]))
h=np.dot(x, w)
print("Predicted Time for the year: ",h[0,0])
