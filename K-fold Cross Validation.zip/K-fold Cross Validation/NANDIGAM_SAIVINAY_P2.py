#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Feb  8 12:15:05 2022

@author: vinaynandigam
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def calculate_weight(X,y):
    A=np.linalg.pinv(np.dot(X.T,X))
    B=np.dot(X.T,y)
    w=np.dot(A,B)
    return w 
def linearModel(train,test, columns):
    rows_train = len(train)
    rows_test = len(test)
    X = np.ones((rows_train,columns+1))
    y = np.zeros((rows_train,1))
    for i in range(0,rows_train):
        lineFeatures=train[i]
        lf=lineFeatures.split("\t")
        y[i,0] = lf[-1]
        lf=lf[:-1]
        for j in range(1,columns+1):
            X[i,j]=lf[j-1]
    w=calculate_weight(X,y)
    A = np.dot(X,w) - y
    J = (1/X.shape[0])*np.dot(A.T,A)
    
    
    
    X1 = np.ones((rows_test,columns+1))
    y1 = np.zeros((rows_test,1))
    for i in range(0,rows_test):
        lineFeatures1=test[i]
        lf1=lineFeatures1.split("\t")
        y1[i,0] = lf1[-1]
        lf1=lf1[:-1]
        for j in range(1,columns+1):
            X1[i,j]=lf1[j-1]
    
    
    A1 = np.dot(X1,w) - y1
    J1 = (1/X1.shape[0])*np.dot(A1.T,A1)
    print("Train Error: ", J[0,0])    
    print("Test Error: ", J1[0,0])    
    return J[0,0],J1[0,0]
def quadraticModel(train,test,columns):
    rows_train=len(train)
    rows_test=len(test)
    X = np.ones((rows_train,columns+2))
    y = np.zeros((rows_train,1))
    for i in range(0,rows_train):
        lineFeatures=train[i]
        lf=lineFeatures.split("\t")
        y[i,0] = lf[-1]
        lf=lf[:-1]
        for j in range(1,columns+2):
            if(j==columns+1):
                X[i,j]=int(lf[0])**2
            else:
                X[i,j]=lf[j-1]
    w=calculate_weight(X,y)
    A = np.dot(X,w) - y
    J = (1/X.shape[0])*np.dot(A.T,A)
    
     
    
    X1 = np.ones((rows_test,columns+2))
    y1 = np.zeros((rows_test,1))
    for i in range(0,rows_test):
        lineFeatures1=test[i]
        lf1=lineFeatures1.split("\t")
        y1[i,0] = lf1[-1]
        lf1=lf1[:-1]
        for j in range(1,columns+2):
            if j==columns+1:
                X1[i,j]=int(lf1[0])**2
            else:
                X1[i,j]=lf1[j-1]
   
    
    
    A1 = np.dot(X1,w) - y1
    J1 = (1/X1.shape[0])*np.dot(A1.T,A1) 
    print("Train Error: ", J[0,0])
    print("Test Error: ", J1[0,0])
    
    
    return J[0,0],J1[0,0]
def cubicModel(train,test,columns):
    rows_train=len(train)
    rows_test=len(test)
    X = np.ones((rows_train,columns+3))
    y = np.zeros((rows_train,1))
    for i in range(0,rows_train):
        lineFeatures=train[i]
        lf=lineFeatures.split("\t")
        y[i,0] = lf[-1]
        lf=lf[:-1]
        for j in range(1,columns+3):
            if(j==columns+1):
                X[i,j]=int(lf[0])**2
            elif(j==columns+2):
                X[i,j]=int(lf[0])**3
            else:
                X[i,j]=lf[j-1]
    w=calculate_weight(X,y)
    A = np.dot(X,w) - y
    J = (1/X.shape[0])*np.dot(A.T,A)
    
    
    
    X1 = np.ones((rows_test,columns+3))
    y1 = np.zeros((rows_test,1))
    for i in range(0,rows_test):
        lineFeatures1=test[i]
        lf1=lineFeatures1.split("\t")
        y1[i,0] = lf1[-1]
        lf1=lf1[:-1]
        for j in range(1,columns+3):
            if j==columns+1:
                X1[i,j]=int(lf1[0])**2
            elif(j==columns+2):
                X1[i,j]=int(lf1[0])**3
            else:
                X1[i,j]=lf1[j-1]
    
    A1 = np.dot(X1,w) - y1
    J1 = (1/X1.shape[0])*np.dot(A1.T,A1)
    

    print("Train Error: ", J[0,0])
    print("Test Error: ", J1[0,0])
   
    
    
   
    return J[0,0],J1[0,0]

def kFold(data,rows,columns):
    k = round(rows/5)
    lf = lineFeatures.split("\t")
    for i in range(0,5):
        if i ==0:
            train = data[0:k*4]
            test = data[k*4:]
            print("Linear 1234 & 5")
            linear_0=linearModel(train,test,columns)
            print("Quadratic 1234 & 5")
            quad_0=quadraticModel(train, test, columns)
            print("Cubic 1234 & 5")
            cube_0=cubicModel(train,test,columns)
        elif i ==1:
            train = data[0:k*3]+data[k*4:]
            test = data[k*3:k*4]
            print("Linear 1235 & 4")
            linear_1=linearModel(train,test,columns)
            print("Quadratic 1235 & 4")
            quad_1=quadraticModel(train, test, columns)
            print("Cubic 1235 & 4")
            cube_1=cubicModel(train,test,columns)
        elif i == 2:
            train = data[0:k*2]+data[k*3:]
            test = data[k*2:k*3]
            print("Linear 1245 & 3")
            linear_2=linearModel(train,test,columns)
            print("Quadratic 1245 & 3")
            quad_2=quadraticModel(train, test, columns)
            print("Cubic 1245 & 3")
            cube_2=cubicModel(train,test,columns)
        elif i == 3:
            train = data[0:k*1]+data[k*2:]
            test = data[k*1:k*2]
            print("Linear 1345 & 2")
            linear_3=linearModel(train,test,columns)
            print("Quadratic 1345 & 2")
            quad_3=quadraticModel(train, test, columns)
            print("Cubic 1345 & 2")
            cube_3=cubicModel(train,test,columns)
        elif i ==4:
            train = data[k:]
            test = data[0:k]
            print("Linear 2345 & 1")
            linear_4=linearModel(train,test,columns)
            print("Quadratic 2345 & 1")
            quad_4=quadraticModel(train, test, columns)
            print("Cubic 2345 & 1")
            cube_4=cubicModel(train,test,columns)
    linearTrainMean= (linear_0[0]+linear_1[0]+linear_2[0]+linear_3[0]+linear_4[0])/5
    linearTestMean= (linear_0[1]+linear_1[1]+linear_2[1]+linear_3[1]+linear_4[1])/5
    
    quadraticTrainMean=(quad_0[0]+quad_1[0]+quad_2[0]+quad_3[0]+quad_4[0])/5
    quadraticTestMean=(quad_0[1]+quad_1[1]+quad_2[1]+quad_3[1]+quad_4[1])/5
    
    
    cubicTrainMean=(cube_0[0]+cube_1[0]+cube_2[0]+cube_3[0]+cube_4[0])/5
    cubicTestMean=(cube_0[1]+cube_1[1]+cube_2[1]+cube_3[1]+cube_4[1])/5
    
    
    print("Linear Train Mean: ", linearTrainMean)
    print("Linear Test Mean: ", linearTestMean)
      
    
    print("Quadratic Train Mean: ", quadraticTrainMean)
    print("Quadratic Test Mean: ",quadraticTestMean)
    
    
    print("Cubic Train Mean: ",cubicTrainMean)
    print("Cubic Test Mean: ", cubicTestMean)
    
    x_coordinates = [1, 2, 3]
    y_coordinates_train = [linearTrainMean, quadraticTrainMean, cubicTrainMean]
    y_coordinates_test = [linearTestMean, quadraticTestMean, cubicTestMean]

    plt.xlim(0,4)
    plt.ylim(-0.5,1)
    t1= plt.scatter(x_coordinates, y_coordinates_train)
    plt.plot(x_coordinates,y_coordinates_train)
    t2= plt.scatter(x_coordinates,y_coordinates_test)
    plt.xlabel("Highest Polynomial Degree")
    plt.ylabel("Squared Error Cost Function (J)")
    plt.legend((t2,t1),( "Testing J","Training J"))
    plt.plot(x_coordinates,y_coordinates_test)
    plt.savefig("adi.png",bbox_inches="tight")
    plt.show()
fileName = input("Enter the name of your file:")
inputFile = open(fileName, "r")
lineFeatures = inputFile.readline()
lineFeatures = lineFeatures.strip()
lf = lineFeatures.split("\t")
rows = int(lf[0])
columns = int(lf[1])
data = []
for i in range(0,rows):
    lineFeatures = inputFile.readline()
    lineFeatures = lineFeatures.strip()
    lineFeatures=lineFeatures.replace(',','')
    data.append(lineFeatures)
kFold(data,rows,columns)           
inputFile.close()          



